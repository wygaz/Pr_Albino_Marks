
from django.urls import path
from . import views

app_name = 'A_Lei_no_NT'

urlpatterns = [
    path('', views.lista_artigos, name='lista_artigos'),
    path('<slug:slug>/', views.visualizar_artigo, name='visualizar_artigo'),
]
